# HÃY DÙNG ĐÚNG CÁCH

B1: Mở kill aura 20m  
B2: mở auto loot 20m, nhớ tích vô cái ô tự mở rương  
B3: lấy file cần thiết  
B4: dán vô folder "teleports" trong file tool, ko có thì tạo  
B5: mở phần tele tùy chỉnh trong tool ấn làm mới  
B6: check phần delay bên trên, hdd 15 - 20s, ssd 8 - 12s  
B7: tích chọn all r bấm nút chọn ở hàng đầu tiên  
CHỜ NÓ CHẠY XONG LÀ ĐC 

